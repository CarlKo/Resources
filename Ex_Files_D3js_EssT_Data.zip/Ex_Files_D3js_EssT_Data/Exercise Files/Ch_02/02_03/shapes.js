var dataArray = [5,11,18];

d3.select("body").append("svg")
    .attr("height","100%")
    .attr("width","100%");
